<div class="sidebar-box">
  <h3 class="heading">Tags</h3>
  <ul class="tags">
    <li><a href="#">Travel</a></li>
  </ul>
</div>
