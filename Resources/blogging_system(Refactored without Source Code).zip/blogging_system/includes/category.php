<div class="sidebar-box">
  <h3 class="heading">Categories</h3>
  <ul class="categories">
    <li><a href="#">Food <span>(12)</span></a></li>
  </ul>
</div>
