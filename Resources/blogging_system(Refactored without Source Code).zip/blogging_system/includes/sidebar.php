<div class="sidebar-box">
  <h3 class="heading">Recent Posts</h3>
  <div class="post-entry-sidebar">
    <ul>
      <li>
        <a href="">
          <img src="images/img_2.jpg" alt="Image placeholder" class="mr-4">
          <div class="text">
            <h4>How to Find the Video Games of Your Youth</h4>
            <div class="post-meta">
              <span class="mr-2">March 15, 2018 </span>
            </div>
          </div>
        </a>
      </li>
    </ul>
  </div>
</div>
